﻿namespace POO_Catedra
{
    partial class AdministrarCita
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgwCitas = new DataGridView();
            btnEliminarC = new Button();
            btnEditarC = new Button();
            btnCrearC = new Button();
            btnVolver = new Button();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgwCitas).BeginInit();
            SuspendLayout();
            // 
            // dgwCitas
            // 
            dgwCitas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgwCitas.Location = new Point(231, 50);
            dgwCitas.Name = "dgwCitas";
            dgwCitas.Size = new Size(437, 314);
            dgwCitas.TabIndex = 9;
            // 
            // btnEliminarC
            // 
            btnEliminarC.Location = new Point(42, 144);
            btnEliminarC.Name = "btnEliminarC";
            btnEliminarC.Size = new Size(136, 40);
            btnEliminarC.TabIndex = 12;
            btnEliminarC.Text = "Eliminar Cita";
            btnEliminarC.UseVisualStyleBackColor = true;
            // 
            // btnEditarC
            // 
            btnEditarC.Location = new Point(42, 84);
            btnEditarC.Name = "btnEditarC";
            btnEditarC.Size = new Size(136, 43);
            btnEditarC.TabIndex = 11;
            btnEditarC.Text = "Editar Cita";
            btnEditarC.UseVisualStyleBackColor = true;
            // 
            // btnCrearC
            // 
            btnCrearC.Location = new Point(42, 24);
            btnCrearC.Name = "btnCrearC";
            btnCrearC.Size = new Size(136, 43);
            btnCrearC.TabIndex = 10;
            btnCrearC.Text = "Crear Cita Medica";
            btnCrearC.UseVisualStyleBackColor = true;
            btnCrearC.Click += btnCrearC_Click;
            // 
            // btnVolver
            // 
            btnVolver.Location = new Point(42, 324);
            btnVolver.Name = "btnVolver";
            btnVolver.Size = new Size(136, 40);
            btnVolver.TabIndex = 13;
            btnVolver.Text = "Volver";
            btnVolver.UseVisualStyleBackColor = true;
            btnVolver.Click += btnVolver_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(387, 24);
            label1.Name = "label1";
            label1.Size = new Size(129, 15);
            label1.TabIndex = 14;
            label1.Text = "Lista de citas existentes";
            // 
            // AdministrarCita
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(705, 397);
            Controls.Add(label1);
            Controls.Add(btnVolver);
            Controls.Add(btnEliminarC);
            Controls.Add(btnEditarC);
            Controls.Add(btnCrearC);
            Controls.Add(dgwCitas);
            Name = "AdministrarCita";
            Text = "Administrar Cita";
            ((System.ComponentModel.ISupportInitialize)dgwCitas).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgwCitas;
        private Button btnEliminarC;
        private Button btnEditarC;
        private Button btnCrearC;
        private Button btnVolver;
        private Label label1;
    }
}