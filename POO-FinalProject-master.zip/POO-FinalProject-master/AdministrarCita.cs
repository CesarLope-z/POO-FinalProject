﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POO_Catedra
{
    public partial class AdministrarCita : Form
    {
        public AdministrarCita()
        {
            InitializeComponent();
        }

        private void btnCrearC_Click(object sender, EventArgs e)
        {
            GenerarCita generarCita = new GenerarCita(this);
            generarCita.Show();
            this.Hide();
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            Administrador Admin = new Administrador();
            Admin.Show();
            this.Hide();
        }
    }
}
