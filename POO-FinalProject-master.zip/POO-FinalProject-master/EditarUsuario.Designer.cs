﻿namespace POO_Catedra
{
    partial class EditarUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label4 = new Label();
            label3 = new Label();
            tbEditPass = new TextBox();
            btnVolver = new Button();
            btnCrear = new Button();
            label2 = new Label();
            label1 = new Label();
            tbEditRol = new TextBox();
            tbEditUsuario = new TextBox();
            SuspendLayout();
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(9, 11);
            label4.Name = "label4";
            label4.Size = new Size(141, 15);
            label4.TabIndex = 23;
            label4.Text = "Edite los datos necesarios";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(73, 233);
            label3.Name = "label3";
            label3.Size = new Size(67, 15);
            label3.TabIndex = 22;
            label3.Text = "Contraseña";
            // 
            // tbEditPass
            // 
            tbEditPass.Location = new Point(73, 264);
            tbEditPass.Name = "tbEditPass";
            tbEditPass.Size = new Size(154, 23);
            tbEditPass.TabIndex = 21;
            // 
            // btnVolver
            // 
            btnVolver.BackColor = SystemColors.MenuHighlight;
            btnVolver.Location = new Point(26, 324);
            btnVolver.Name = "btnVolver";
            btnVolver.Size = new Size(71, 28);
            btnVolver.TabIndex = 20;
            btnVolver.Text = "Volver";
            btnVolver.UseVisualStyleBackColor = false;
            btnVolver.Click += btnVolver_Click;
            // 
            // btnCrear
            // 
            btnCrear.BackColor = SystemColors.MenuHighlight;
            btnCrear.Location = new Point(169, 324);
            btnCrear.Name = "btnCrear";
            btnCrear.Size = new Size(126, 28);
            btnCrear.TabIndex = 19;
            btnCrear.Text = "Crear";
            btnCrear.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(73, 138);
            label2.Name = "label2";
            label2.Size = new Size(24, 15);
            label2.TabIndex = 18;
            label2.Text = "Rol";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(73, 45);
            label1.Name = "label1";
            label1.Size = new Size(47, 15);
            label1.TabIndex = 17;
            label1.Text = "Usuario";
            // 
            // tbEditRol
            // 
            tbEditRol.Location = new Point(73, 169);
            tbEditRol.Name = "tbEditRol";
            tbEditRol.Size = new Size(154, 23);
            tbEditRol.TabIndex = 16;
            // 
            // tbEditUsuario
            // 
            tbEditUsuario.Location = new Point(73, 77);
            tbEditUsuario.Name = "tbEditUsuario";
            tbEditUsuario.Size = new Size(154, 23);
            tbEditUsuario.TabIndex = 15;
            // 
            // EditarUsuario
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(318, 385);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(tbEditPass);
            Controls.Add(btnVolver);
            Controls.Add(btnCrear);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(tbEditRol);
            Controls.Add(tbEditUsuario);
            Name = "EditarUsuario";
            Text = "Editar Usuario";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label4;
        private Label label3;
        private TextBox tbEditPass;
        private Button btnVolver;
        private Button btnCrear;
        private Label label2;
        private Label label1;
        private TextBox tbEditRol;
        private TextBox tbEditUsuario;
    }
}