﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POO_Catedra
{
    public partial class GenerarCita : Form
    {

        private Form FormAnterior;
        public GenerarCita(Form FormAnterior)
        {
            InitializeComponent();
            this.FormAnterior = FormAnterior;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close(); 
            FormAnterior.Show();
        }
    }
}
